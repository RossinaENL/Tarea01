package com.juangabrielgomila.counter; //identificador, APUNTA A LA VERSION DEL SDK QUE SE ESTA USANDO

/*Importando librerias necesarias*/
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


//Método prinicipal de la Ventana predeterminada donde podemos colocar diferentes componentes como
// Button, EditText, TextView, Spinner, etc.
//Proporciona métodos de ciclo de vida para actividades tales como onCreate, onStop, OnResume, etc.
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //Variable para sostener el valor entero que vamos a mostrar
    private int value = 0;

    //Variables para los 6 botones y la text view
    private TextView textView;
    private Button btnAdd, btnTake, btnGrow, btnShrink, btnHide, btnReset;


//Método para iniciar la actividad
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//  Se define el layout (diseño que tendrá la aplicación), se llama a activity_main.xml
        setContentView(R.layout.activity_main);

        //Se da el valor de las variables a los 6 botones y la textView que se encuentran en el activity_main.xml
        textView = (TextView) findViewById(R.id.text_view);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        btnTake = (Button) findViewById(R.id.btnTake);
        btnGrow = (Button) findViewById(R.id.btnGrow);
        btnShrink = (Button) findViewById(R.id.btnShrink);
        btnHide = (Button) findViewById(R.id.btnHide);
        btnReset = (Button) findViewById(R.id.btnReset);

        /*el metodo setOnClickListener de los 6 botones*/
        btnAdd.setOnClickListener(this);
        btnTake.setOnClickListener(this);
        btnGrow.setOnClickListener(this);
        btnShrink.setOnClickListener(this);
        btnHide.setOnClickListener(this);
        btnReset.setOnClickListener(this);

    }

    //Inicio de método con las acciones de los botones
    @Override
    public void onClick(View view) {
        Log.i("Main Activity", "onClick: "+view.getId());
        float scale;

//permite dar clic a cualquiera de los 6 botones y realizar una acción diferente
        switch (view.getId()){

            //Aumenta la cantidad dentro del contador
            case R.id.btnAdd:
                value++;
                textView.setText(""+value);
                break;
            //Disminuye la cantidad dentro del contador
            case R.id.btnTake:
                value--;
                textView.setText(""+value);
                break;

            //Reinicia el conteo
            case R.id.btnReset:
                value = 0;
                textView.setText(""+value);
                break;

            //Aumenta el tamaño de la letra del contador
            case R.id.btnGrow:
                scale = textView.getTextScaleX();
                scale = scale +1;
                textView.setTextScaleX(scale);
                break;

              //Disminuye el tamaño de la letra del contador
            case R.id.btnShrink:
                scale = textView.getTextScaleX();
                scale = scale -1;
                textView.setTextScaleX(scale);
                break;

           //Esta acción del botón usa un if con dos opciones: para mostrar y ocultar el contador.
            case R.id.btnHide:
                if (textView.getVisibility() == View.VISIBLE){
                    //En este caso, la vista está visible y debemos ocultarla....
                    textView.setVisibility(View.INVISIBLE);
                    btnHide.setText("Mostrar");
                }else {
                    //En este caso, la vista está invisible, debemos mostrarla...
                    textView.setVisibility(View.VISIBLE);
                    btnHide.setText("Ocultar");
                }
                break;
        }
    }//Termina el método con las acciones de los botones
}
